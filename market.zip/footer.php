<div>
</body>

<footer class="footer" style="background-color: green; padding: 10px; color: white;">
	&copy; Copyright Department of Footwear Technology
</footer>
</body>
