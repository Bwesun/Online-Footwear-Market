<?php
include('connect.php');

session_start();


include('head.php');

?>

	<style type="text/css">
		.panel-heading{
		}
	</style>



		<div class="container">
			<div class="jumbotron">
			<h1>Welcome to Department of Footwear Technology!</h1>
			<p>Online Market</p>
			<?php
if(!isset($_SESSION['user_id'])){
	echo '
	<a role="link" href="login.php" class="btn btn-lg btn-bg btn-success">Get Started</a>
			<a class="btn btn-info btn-bg btn-lg" href="login.php">Login <i class="fas fa-user"></i></a> ';
}else{
	echo '
<a role="link" href="products.php" class="btn btn-lg btn-bg btn-success"> Start Shopping</a>
';
}
			?>
			


			</div>
		</div>


		<!-- Login Modal 1 -->



	

</body>

		



<?php

include('footer.php');

?>









