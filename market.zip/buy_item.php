<?php
session_start();
include('head.php');

include('connect.php');

$user_id=$_SESSION['user_id']

$use_id=$_GET['id'];

?>

