<?php
include('connect.php');

session_start();


include('head.php');

?>

	<style type="text/css">
		#link{

		}
	</style>

<div class="container">
	<div class="col-md-1">
		
	</div>

	<div class="col-md-8">
		<fieldset>
			<legend>My Cart</legend>
			<table class="table">
				<tr>
					<td colspan=""><h2>Your Transaction Pin: <?php echo $_SESSION['trans_pin'] ?> </h2></td>
				</tr>
				<tr>
					<td>Pay at Any Bank Branch. Below are Bank Details:</td>
				</tr>
				<tr>
					<td>Account Name: NILESTFOOT Ltd</td>
				</tr>
				<tr>
					<td>Union Bank<br>
					Acct No: 008872266</td>
				</tr><tr>
					<td>First Bank<br>Acct No: 008872266</td>
				</tr><tr>
					<td>Access Bank<br>Acct No: 008872266</td>
				</tr>
			</table>
		</fieldset>
	</div>
</div>

	

</body>

		



<?php

include('footer.php');

?>









