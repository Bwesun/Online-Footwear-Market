<?php
session_start();
include('connect.php');

if(!isset($_SESSION['admin_user'])){
	echo "<script>alert('Please Login as An Admin')</script>";
	echo "<script>window.open('login.php', '_self')</script>";
	
}

include('head.php');
?>

<table class="table navbar navbar-default navbar-fixed-top">
	<tr>
		<th><a href="index.php" >Home</a></th>
		<th><a href="logout.php" >Logout</a></th>
	</tr>
</table>
<br>
<br>
<br>
<br>
<style type="text/css">
	body{
		margin: 1%;
	}
	.col-md-2 a{
	    padding:8px; 
	    background-color: #eeeeee;
	}
	.col-md-2 a:hover{
	    color: white;
	    background-color: #66CC99;
	    font-weight: bolder;
	}
</style>

<body>
		<div class="row">
			<div class="col-md-2">
				<br>
				<br>
				<br>
				<a href="index.php" class="form-control">View Orders</a><br>
				<a href="add_item.php" class="form-control">Add Item</a><br>
				<a href="view_complaints.php" class="form-control">View Complaints</a><br>
			</div>



			<div class="col-md-9">
				<h2>Orders</h2>
			<table class="table table-condensed table-striped">
				<tr>
					<th>Date</th>
					<th>Customer Name</th>
					<th>Item Name</th>
					<th>Total Price</th>
					<th>Actions</th>
				</tr>
				<tr>
						<td>21/23/2222</td>
						<td>Aliyu Hassan Altukry</td>
						<td>Cascette</td>
						<td>#676,896</td>
						<td><a href="" class="btn btn-warning">View</a>  </td>
				</tr>
			</table>


				<p>
				<img src="../slide2.jpg" width="100"><br>
				<p>Wrist Watch</p>
				<p>#2,000</p>
				<p><a href="">Buy</a></p>
				</p>
			</div>
		</div>
	</div>
</body>